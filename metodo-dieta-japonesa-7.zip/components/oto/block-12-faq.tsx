'use client'

import { useState } from 'react'
import { Plus, Minus, HelpCircle } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Reveal } from './reveal'
import { Section, Kicker, Heading } from './shared'

const FAQS = [
  {
    q: '¿Necesito comprar algo más?',
    a: 'No. El método está diseñado para seguirse en casa, con ingredientes accesibles y pasos sencillos. No necesitas productos especiales.',
  },
  {
    q: '¿Cuánto tiempo al día tengo que dedicarle?',
    a: 'El método está organizado en 14 días para ayudarte a crear una rutina progresiva y sencilla.',
  },
  {
    q: '¿Sirve si tengo poca movilidad o me canso rápido?',
    a: 'El sistema es progresivo y comienza con prácticas muy suaves. Aun así, si tienes una condición específica, consulta siempre con tu profesional de la salud antes de empezar.',
  },
  {
    q: '¿Esto sustituye a mi tratamiento médico?',
    a: 'No. Es un programa educativo enfocado en equilibrio, movilidad y seguridad al caminar. No sustituye la orientación ni el tratamiento de un profesional de la salud.',
  },
  {
    q: '¿Cómo accedo después de comprar?',
    a: 'El acceso es inmediato y digital. Una vez confirmado tu pago, recibirás el Protocolo y los bonos para empezar hoy mismo.',
  },
  {
    q: '¿Y si no funciona para mí?',
    a: 'Cuentas con la garantía de 7 días. Si no quedas satisfecho, te devolvemos el 100% de tu dinero escribiéndonos dentro de ese plazo.',
  },
]

function FaqItem({ q, a, index }: { q: string; a: string; index: number }) {
  const [open, setOpen] = useState(index === 0)
  return (
    <div className="overflow-hidden rounded-2xl border border-border bg-card">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-4 px-4 py-3 text-left"
      >
        <span className="font-display text-xs font-bold uppercase leading-snug tracking-tight text-foreground sm:text-sm">
          {q}
        </span>
        <span
          className={cn(
            'flex size-7 shrink-0 items-center justify-center rounded-full transition-colors',
            open ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground',
          )}
        >
          {open ? <Minus className="size-4" /> : <Plus className="size-4" />}
        </span>
      </button>
      <div
        className={cn(
          'grid transition-all duration-300 ease-out',
          open ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0',
        )}
      >
        <div className="overflow-hidden">
          <p className="px-4 pb-4 text-pretty text-xs leading-5 text-muted-foreground">
            {a}
          </p>
        </div>
      </div>
    </div>
  )
}

export function Block12Faq() {
  return (
    <Section>
      <Reveal className="text-center">
        <Kicker>
          <HelpCircle className="size-4" />
          Preguntas frecuentes
        </Kicker>
        <Heading className="mt-6">Resolvemos tus dudas</Heading>
      </Reveal>

      <div className="mt-8 space-y-3">
        {FAQS.map((f, i) => (
          <Reveal key={f.q} delay={60 + i * 60}>
            <FaqItem q={f.q} a={f.a} index={i} />
          </Reveal>
        ))}
      </div>
    </Section>
  )
}
