'use client'

import { ArrowRight } from 'lucide-react'
import { cn } from '@/lib/utils'

export const CHECKOUT_URL = 'https://pay.hotmart.com/H107399696B?off=w3p9uk6o'

interface CtaButtonProps {
  children: React.ReactNode
  className?: string
  size?: 'default' | 'lg'
  subtle?: boolean
  /** If set, the button smooth-scrolls to this element id instead of opening the checkout. */
  scrollTo?: string
  /** Destination URL. Defaults to the Hotmart checkout. Ignored when scrollTo is set. */
  href?: string
}

export function CtaButton({
  children,
  className,
  size = 'default',
  subtle = false,
  scrollTo,
  href = CHECKOUT_URL,
}: CtaButtonProps) {
  function handleClick() {
    if (scrollTo) {
      document.getElementById(scrollTo)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
      return
    }
    // Open checkout in a new tab when embedded in an iframe (e.g. preview), else navigate.
    if (typeof window !== 'undefined' && window.self !== window.top) {
      window.open(href, '_blank', 'noopener,noreferrer')
    } else {
      window.location.href = href
    }
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      className={cn(
        'group relative inline-flex min-h-14 w-full max-w-[320px] items-center justify-center gap-2 overflow-hidden rounded-2xl px-4 py-3 font-display text-[13px] font-extrabold uppercase leading-[1.2] tracking-tight text-primary-foreground shadow-lg transition-transform duration-200 hover:-translate-y-0.5 active:translate-y-0 cta-glow sm:min-h-11 sm:rounded-full sm:px-4 sm:text-xs',
        'bg-[linear-gradient(100deg,var(--primary),color-mix(in_oklch,var(--primary),black_20%))]',
        size === 'lg' ? 'px-4 py-2 text-xs sm:px-5 sm:py-2.5 sm:text-sm' : 'px-3 py-2 text-[11px] sm:px-4 sm:py-2.5 sm:text-xs',
        !subtle && 'animate-pulse-ring',
        className,
      )}
    >
      <span
        aria-hidden
        className="absolute inset-0 -translate-x-full bg-[linear-gradient(100deg,transparent,rgba(255,255,255,0.35),transparent)] transition-transform duration-700 group-hover:translate-x-full"
      />
      <span className="relative flex max-w-[270px] items-center gap-2 text-center text-[13px] leading-[1.2] sm:text-xs">
        {children}
        <ArrowRight className="size-4 shrink-0 transition-transform duration-200 group-hover:translate-x-1 sm:size-5" />
      </span>
    </button>
  )
}
