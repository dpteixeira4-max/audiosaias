'use client'

import { Calendar, RotateCcw } from 'lucide-react'
import { Reveal } from './reveal'
import { Section } from './shared'

export function Block10Guarantee() {
  return (
    <Section tone="muted">
      <Reveal>
        <div className="relative overflow-hidden rounded-3xl border border-success/30 bg-card p-4 shadow-lg shadow-success/5 sm:p-8">
          <div className="flex flex-col items-center text-center">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ChatGPT%20Image%2028_08_2026%2C%2016_35_03-57hXb4hXBsg4xIQ5NS3MGCEyFekziK.png"
              alt="Sello de garantía de 7 días"
              className="size-36 object-contain drop-shadow-xl sm:size-44"
            />
            <p className="mt-4 font-display text-xs font-bold uppercase tracking-[0.2em] text-success">
              Garantía
            </p>
            <h2 className="mt-2 text-balance font-display text-2xl font-extrabold uppercase leading-tight tracking-tight sm:text-3xl">
              Garantía de satisfacción de 7 días
            </h2>
            <p className="mx-auto mt-4 max-w-lg text-pretty text-base leading-relaxed text-muted-foreground">
              Prueba el Protocolo de 5 Días completo. Si sientes que no es para ti, escríbenos
              dentro de los primeros 7 días y te devolvemos el 100% de tu dinero. Sin
              preguntas incómodas.
            </p>
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-2">
            <div className="flex items-center gap-3 rounded-2xl border border-border bg-secondary px-4 py-4">
              <Calendar className="size-6 shrink-0 text-success" />
              <p className="text-sm font-medium text-foreground">
                7 días completos para probarlo sin riesgo
              </p>
            </div>
            <div className="flex items-center gap-3 rounded-2xl border border-border bg-secondary px-4 py-4">
              <RotateCcw className="size-6 shrink-0 text-success" />
              <p className="text-sm font-medium text-foreground">
                Reembolso del 100% si no quedas satisfecho
              </p>
            </div>
          </div>
        </div>
      </Reveal>
    </Section>
  )
}
