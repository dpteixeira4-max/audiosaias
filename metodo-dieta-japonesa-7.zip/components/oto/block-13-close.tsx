'use client'

import { Flame, ArrowDown, XCircle, CheckCircle2, Footprints, RefreshCw, Puzzle, ClipboardCheck, ShieldCheck, Zap } from 'lucide-react'
import { Reveal } from './reveal'
import { Section, Heading } from './shared'
import { CtaButton } from './cta-button'
import { Countdown } from './countdown'

export function Block13Close() {
  return (
    <Section id="cierre" className="bg-gradient-to-b from-background via-background to-primary/[0.04] pb-16 pt-10 sm:pb-20 sm:pt-14">
      <Reveal className="text-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/10 px-3 py-1.5 font-display text-[10px] font-bold uppercase tracking-[0.16em] text-primary sm:px-4 sm:text-xs sm:tracking-[0.18em]">
          <Flame className="size-3.5 sm:size-4" />
          Última decisión
        </span>
        <Heading className="mx-auto mt-5 max-w-xl text-[1.75rem] leading-[1.08] sm:mt-6 sm:text-4xl">Tienes dos caminos ahora mismo</Heading>
        <p className="mx-auto mt-4 max-w-lg text-pretty text-sm leading-6 text-muted-foreground sm:text-base">
          La decisión es tuya, pero esta condición especial solo está disponible en esta página.
        </p>
      </Reveal>

      <div className="mt-7 grid gap-4 sm:mt-8 sm:grid-cols-2">
        <Reveal delay={80}>
          <div className="flex h-full flex-col rounded-2xl border border-border/80 bg-card/90 p-5 shadow-[0_12px_30px_color-mix(in_oklab,var(--primary)_6%,transparent)] sm:rounded-3xl sm:p-6">
            <XCircle className="size-8 text-muted-foreground" />
            <p className="mt-3 font-display text-lg font-extrabold uppercase tracking-tight">
              Cerrar esta página
            </p>
            <p className="mt-2 text-pretty text-sm leading-relaxed text-muted-foreground">
              Te quedas únicamente con El Truco de la Pimienta y tendrás que organizar por tu cuenta cómo trabajar aspectos importantes como:
            </p>
            <ul className="mt-4 space-y-2 text-sm leading-relaxed text-muted-foreground">
              <li>→ Equilibrio</li>
              <li>→ Estabilidad</li>
              <li>→ Movilidad</li>
              <li>→ Seguridad al caminar</li>
            </ul>
            <p className="mt-4 text-pretty text-sm leading-relaxed text-muted-foreground">
              Además, esta condición especial de US$17 está disponible como complemento de tu compra actual y puede no volver a aparecer bajo las mismas condiciones.
            </p>
          </div>
        </Reveal>

        <Reveal delay={160}>
          <div className="relative flex h-full flex-col overflow-hidden rounded-3xl border-2 border-primary/45 bg-primary/[0.07] p-5 shadow-[0_16px_36px_color-mix(in_oklab,var(--primary)_10%,transparent)] sm:p-6"><span className="absolute right-5 top-0 rounded-b-lg bg-primary px-3 py-1 font-display text-[10px] font-extrabold uppercase tracking-[0.14em] text-primary-foreground">Recomendado</span>
            <CheckCircle2 className="size-8 text-primary" />
            <p className="mt-3 font-display text-lg font-extrabold uppercase tracking-tight">
              Añadir el protocolo completo a mi rutina
            </p>
            <p className="mt-2 text-pretty text-sm leading-relaxed text-muted-foreground">
              Puedes aprovechar ahora esta oferta especial y añadir a tu pedido:
            </p>
            <ul className="mt-4 space-y-2 text-sm leading-relaxed text-muted-foreground">
              <li className="flex items-center gap-2"><Footprints className="size-4 shrink-0 text-primary" />Protocolo completo de 5 días</li>
              <li className="flex items-center gap-2"><RefreshCw className="size-4 shrink-0 text-primary" />Sistema progresivo de 3 fases</li>
              <li className="flex items-center gap-2"><Puzzle className="size-4 shrink-0 text-primary" />Generador de Ejercicios</li>
              <li className="flex items-center gap-2"><ClipboardCheck className="size-4 shrink-0 text-primary" />Checklist Diario del Progreso</li>
              <li className="flex items-center gap-2"><ShieldCheck className="size-4 shrink-0 text-primary" />Guía de Seguridad y Precauciones</li>
              <li className="flex items-center gap-2"><Zap className="size-4 shrink-0 text-primary" />Acceso inmediato</li>
              <li className="flex items-center gap-2"><ShieldCheck className="size-4 shrink-0 text-primary" />Garantía de 7 días</li>
            </ul>
            <p className="mt-4 font-display text-lg font-extrabold text-primary">Todo por solo US$17</p>
          </div>
        </Reveal>
      </div>

      <Reveal delay={120} className="mt-10">
        <div className="rounded-3xl bg-foreground p-6 text-center text-background sm:p-8">
          <p className="font-display text-sm font-bold uppercase tracking-widest text-background/60">
            La oferta expira en
          </p>
          <div className="mt-4">
            <Countdown />
          </div>
          <div className="mx-auto mt-8 flex items-center justify-center gap-2 text-background/60">
            <ArrowDown className="size-5 animate-bounce" />
          </div>
          <div className="mt-4">
            <CtaButton size="default" subtle className="px-4 py-3 text-[13px] leading-tight sm:px-6 sm:py-5 sm:text-lg"><span className="max-w-[15rem] text-balance">SÍ, QUIERO AÑADIR EL PROTOCOLO POR US$17</span></CtaButton>
          </div>
          <p className="mt-4 text-xs text-background/50">
            Pago único · Sin suscripciones · Acceso inmediato
          </p>
          <p className="mt-3 text-sm font-semibold text-background/80">
            No necesitas decidirlo después.
          </p>
          <p className="mt-2 text-xs leading-relaxed text-background/50">
            Esta es la condición especial disponible ahora mismo para completar tu rutina.
          </p>
        </div>
      </Reveal>

      <Reveal delay={100} className="mt-10 text-center">
        <p className="text-pretty text-sm leading-relaxed text-muted-foreground">
          Cuida tus pies. Cuida tu equilibrio. Cuida tu libertad de caminar.
        </p>
      </Reveal>
    </Section>
  )
}
