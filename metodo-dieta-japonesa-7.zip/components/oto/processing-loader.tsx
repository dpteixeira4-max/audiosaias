'use client'

import { useEffect, useState } from 'react'
import { AlertTriangle, Check, Loader2, ShieldCheck, Flame, Footprints, HeartPulse, ShieldAlert, ScanEye } from 'lucide-react'
import { cn } from '@/lib/utils'

const DEFAULT_STEPS = [
  'Confirmando tu compra de Protocolo de la Gimnasta de 5 Días',
  'Asegurando tu conexión de pago',
  'Preparando tu acceso especial',
]

interface ProcessingLoaderProps {
  onDone: () => void
  badge?: string
  title?: string
  subtitle?: string
  steps?: string[]
  duration?: number
}

export function ProcessingLoader({
  onDone,
  badge = 'Paso 1 de 3',
  title = 'Preparando tu pedido',
  subtitle = 'Confirmando tu compra de Protocolo de la Gimnasta de 5 Días',
  steps = DEFAULT_STEPS,
  duration = 5200,
}: ProcessingLoaderProps) {
  const isPaso2 = badge.toLowerCase().includes('paso 2')
  const activeDuration = duration
  const [step, setStep] = useState(0)
  const [progress, setProgress] = useState(6)
  const [closing, setClosing] = useState(false)

  useEffect(() => {
    const timers: number[] = []
    steps.forEach((_, i) => {
      const stepTime = Math.round(((i + 1) / steps.length) * Math.max(activeDuration - 400, 400))
      timers.push(window.setTimeout(() => setStep(i + 1), stepTime))
    })
    timers.push(window.setTimeout(() => setProgress(100), Math.max(activeDuration - 220, 0)))
    timers.push(window.setTimeout(() => setClosing(true), activeDuration - 650))
    timers.push(window.setTimeout(() => onDone(), activeDuration))
    return () => timers.forEach((t) => window.clearTimeout(t))
  }, [activeDuration, onDone, steps])

  useEffect(() => {
    const tick = 100 / Math.max(activeDuration / 100, 1)
    const id = window.setInterval(() => {
      setProgress((p) => Math.min(100, p + tick))
    }, 100)
    return () => window.clearInterval(id)
  }, [activeDuration])

  if (isPaso2) {
    return (
      <div className={cn('fixed inset-0 z-50 flex justify-center overflow-y-auto bg-white px-2 py-4 text-slate-900 transition-opacity duration-500', closing && 'pointer-events-none opacity-0')} role="status" aria-live="polite">
        <div className="h-fit w-full max-w-[300px]">
          <div className="flex items-center justify-center rounded-full border border-pink-200 bg-pink-50 px-2 py-1.5 text-center font-display text-[8px] font-bold uppercase tracking-wide text-pink-600">
            <AlertTriangle className="mr-1 size-2.5 animate-blink" /> Paso 2 de 3: ¡No cierres esta página!
          </div>
          <div className="mt-5 text-center">
            <span className="inline-flex items-center gap-1 rounded-full border border-pink-200 px-3 py-1 font-display text-[8px] font-bold uppercase tracking-[0.18em] text-pink-600"><Flame className="size-2.5" /> Atención</span>
            <h1 className="mt-3 text-balance font-display text-[1.45rem] font-extrabold uppercase leading-[0.98] tracking-tight text-slate-900">
              TU PEDIDO DEL <span className="text-pink-600">PROTOCOLO DE LA GIMNASTA DE 5 DÍAS</span> ESTÁ CASI COMPLETO...
            </h1>
            <p className="mt-3 text-[11px] leading-relaxed text-slate-600">Pero hay algo más muy importante que todavía necesitas saber.</p>
          </div>
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ChatGPT%20Image%2030_08_2026%2C%2016_11_52-ecLzt48XrI6DVVTLCJBJKFnXcjHzft.png"
            alt="Mujer mayor sentada junto a una silla de ruedas"
            className="mt-3 max-h-[170px] w-full rounded-xl object-cover object-center"
          />
          <div className="mt-5 space-y-3 text-[10px] leading-[1.45] text-slate-600">
            <p>El Protocolo de la Gimnasta te ayudó a caminar con mayor equilibrio y firmeza. Sin embargo, una alimentación inadecuada y niveles elevados de glucosa pueden aumentar el riesgo de complicaciones graves en los pies.</p>
            <p className="font-display font-bold uppercase text-slate-900">Y AHÍ PUEDE APARECER OTRO PROBLEMA:</p>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            {[[ScanEye, 'Heridas que pasan desapercibidas'], [HeartPulse, 'Complicaciones relacionadas con la diabetes'], [Footprints, 'Deterioro de la salud de tus pies'], [ShieldAlert, 'Riesgo de amputación']].map(([Icon, label]: any) => <div key={label} className="flex min-h-[68px] flex-col items-center justify-center gap-1 rounded-xl border border-pink-200 bg-pink-50 px-2 text-center"><Icon className="size-5 text-pink-500" aria-hidden="true" /><span className="text-[8px] font-semibold leading-tight text-slate-700">{label}</span></div>)}
          </div>
          <p className="mt-5 text-center text-[10px] leading-relaxed text-slate-600">Trabajar sobre el equilibrio es solo el <strong className="text-slate-900">segundo paso</strong>.</p>
          <div className="mt-4 h-1 overflow-hidden rounded-full bg-pink-100"><div className="h-full rounded-full bg-pink-500 transition-[width] duration-300" style={{ width: `${Math.min(progress, 100)}%` }} /></div>
        </div>
      </div>
    )
  }

  return (
    <div className={cn('fixed inset-0 z-50 flex items-center justify-center bg-white px-5 text-slate-900 transition-opacity duration-500', closing && 'pointer-events-none opacity-0')} role="status" aria-live="polite">
      <div className="w-full max-w-md"><div className="mb-6 flex justify-center text-center"><span className="inline-flex items-center justify-center gap-2 rounded-full border border-pink-200 px-4 py-1.5 font-display text-xs font-bold uppercase tracking-[0.2em] text-pink-600"><ShieldCheck className="size-4" />{badge}</span></div><div className="flex flex-col items-center justify-center gap-3 text-center"><Loader2 className="size-6 shrink-0 animate-spin text-pink-600" /><h1 className="w-full text-center font-display text-2xl font-extrabold uppercase leading-tight tracking-tight sm:text-3xl">{title}...</h1></div><div className="mt-8 h-2.5 w-full overflow-hidden rounded-full bg-pink-100"><div className="h-full rounded-full bg-pink-500 transition-[width] duration-200" style={{ width: `${Math.min(progress, 100)}%` }} /></div><ul className="mt-6 space-y-3">{steps.map((label, i) => { const done = step > i; const active = step === i; return <li key={label} className={cn('flex items-center gap-3 rounded-xl border border-pink-200 bg-pink-50 px-4 py-3 text-sm', done && 'border-pink-300 bg-pink-100')}><span className={cn('flex size-6 shrink-0 items-center justify-center rounded-full border', done ? 'border-pink-500 bg-pink-500 text-white' : 'border-pink-300 text-pink-600')}>{done ? <Check className="size-4" /> : active ? <Loader2 className="size-3.5 animate-spin" /> : <span className="size-2 rounded-full bg-pink-300" />}</span><span className={cn(done ? 'text-slate-900' : 'text-slate-600')}>{label}</span></li> })}</ul></div>
    </div>
  )
}

