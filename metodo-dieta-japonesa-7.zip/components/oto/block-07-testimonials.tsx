'use client'

import { Star, Quote } from 'lucide-react'
import { Reveal } from './reveal'
import { Section, Kicker, Heading } from './shared'

const TESTIMONIALS = [
  {
    name: 'Carmen R.',
    age: '68 años',
    photo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/random-person%20%284%29-LLkQPy7rFP7lEKInqUNB6v5ui71ZJ7.jpeg',
    text: 'Después de los 5 días empecé a levantarme del sofá sin agarrarme a todo. Me siento mucho más segura caminando por casa.',
  },
  {
    name: 'José Luis M.',
    age: '72 años',
    photo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/random-person%20%283%29-C6WvDGL272vdKARSupnW9ktzBKPXVl.jpeg',
    text: 'Lo que más noté fue al girar. Antes me mareaba y ahora tengo más control. Las prácticas son cortas y fáciles de seguir.',
  },
  {
    name: 'Antonia G.',
    age: '65 años',
    photo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/random-person%20%285%29-FnyBfLHlM3T5bwHQ0aLAXxznrCvx9P.jpeg',
    text: 'El método me ayudó a organizar la alimentación y revisar mis pies dentro de una rutina diaria. No es una promesa mágica, es una estructura práctica.',
  },
]

export function Block07Testimonials() {
  return (
    <Section>
      <Reveal className="text-center">
        <Kicker>
          <Star className="size-4 fill-current" />
          Testimonios
        </Kicker>
        <Heading className="mt-6">Personas que organizaron su rutina de autocuidado</Heading>
      </Reveal>

      <div className="mt-8 space-y-4">
        {TESTIMONIALS.map((t, i) => (
          <Reveal key={t.name} delay={80 + i * 90}>
            <figure className="rounded-3xl border border-border bg-card p-6">
              <Quote className="size-7 text-primary/40" />
              <blockquote className="mt-3 text-pretty text-base leading-relaxed text-foreground">
                {t.text}
              </blockquote>
              <div className="mt-4 flex items-center gap-1 text-primary" aria-label="5 de 5 estrelas">
                {Array.from({ length: 5 }).map((_, s) => (
                  <Star key={s} className="size-4 fill-current" />
                ))}
              </div>
              <figcaption className="mt-3 flex items-center gap-3">
                <img
                  src={t.photo || "/placeholder.svg"}
                  alt={`Foto de ${t.name}`}
                  className="size-11 shrink-0 rounded-full object-cover ring-2 ring-primary/20"
                />
                <span>
                  <span className="block font-display text-sm font-bold uppercase tracking-tight">
                    {t.name}
                  </span>
                  <span className="block text-xs text-muted-foreground">{t.age}</span>
                </span>
              </figcaption>
            </figure>
          </Reveal>
        ))}
      </div>

      <Reveal delay={100} className="mt-6">
        <p className="text-center text-xs text-muted-foreground">
          Los resultados pueden variar de una persona a otra. Este programa es educativo y no
          sustituye la orientación de un profesional de la salud.
        </p>
      </Reveal>
    </Section>
  )
}
