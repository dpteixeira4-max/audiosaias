'use client'

import { Check, User } from 'lucide-react'
import { Reveal } from './reveal'
import { Section, Kicker, Heading } from './shared'

const CASE_B = [
  'Volvió a caminar con mayor confianza',
  'Se sintió más estable durante sus desplazamientos',
  'Recuperó mayor seguridad al levantarse y girar',
  'Dejó de sentir que cada paso era una amenaza',
  'Volvió a moverse por casa con mucha más tranquilidad',
]

export function Block04Cases() {
  return (
    <Section tone="muted">
      <Reveal className="text-center">
        <Kicker>Prueba por caso doble</Kicker>
        <Heading className="mt-6">
          Todo comenzó con una pregunta muy simple
        </Heading>
        <p className="mx-auto mt-5 max-w-xl text-pretty text-lg italic text-muted-foreground">
          “¿Qué pasa después de conseguir aliviar parte de las molestias?”
        </p>
      </Reveal>

      <Reveal delay={100} className="mt-6">
        <p className="text-pretty text-center text-base leading-relaxed text-muted-foreground">
          Reducir el malestar puede ser importante… pero recuperar confianza al caminar
          requiere trabajar otra dimensión del problema.
        </p>
      </Reveal>

      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        <Reveal delay={80}>
          <article className="flex h-full flex-col rounded-3xl border border-border bg-card p-6">
            <header className="flex items-center gap-3">
              <span className="flex size-11 items-center justify-center rounded-full bg-secondary text-muted-foreground">
                <User className="size-5" />
              </span>
              <div>
                <p className="font-display text-lg font-extrabold uppercase tracking-tight">Caso A</p>
                <p className="text-xs text-muted-foreground">Solo el protocolo de equilibrio</p>
              </div>
            </header>
            <ul className="mt-5 space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <Check className="mt-0.5 size-4 shrink-0 text-success" />
                Menos preocupación por el ardor
              </li>
              <li className="flex items-start gap-2">
                <Check className="mt-0.5 size-4 shrink-0 text-success" />
                Mayor comodidad durante determinados momentos
              </li>
            </ul>
            <p className="mt-auto pt-5 text-pretty text-sm font-medium text-destructive">
              Pero continuaba sintiéndose inseguro al levantarse, girar y caminar.
            </p>
          </article>
        </Reveal>

        <Reveal delay={160}>
          <article className="relative flex h-full flex-col rounded-3xl border-2 border-primary/40 bg-card p-6 shadow-lg shadow-primary/5">
            <span className="absolute -top-3 right-5 rounded-full bg-primary px-3 py-1 font-display text-[0.65rem] font-bold uppercase tracking-wide text-primary-foreground">
              El método completo
            </span>
            <header className="flex items-center gap-3">
              <span className="flex size-11 items-center justify-center rounded-full bg-primary/15 text-primary">
                <User className="size-5" />
              </span>
              <div>
                <p className="font-display text-lg font-extrabold uppercase tracking-tight">Caso B</p>
                <p className="text-xs text-muted-foreground">Protocolo + Método de 14 días</p>
              </div>
            </header>
            <ul className="mt-5 space-y-2.5 text-sm text-foreground">
              {CASE_B.map((item) => (
                <li key={item} className="flex items-start gap-2">
                  <Check className="mt-0.5 size-4 shrink-0 text-success" />
                  {item}
                </li>
              ))}
            </ul>
          </article>
        </Reveal>
      </div>

      <Reveal delay={120} className="mt-10 text-center">
        <p className="text-pretty text-base leading-relaxed text-muted-foreground">
          La diferencia no estaba solamente en <strong className="text-foreground">qué utilizaban</strong>.
          Estaba en{' '}
          <strong className="text-primary">qué más hacían para trabajar su movilidad y equilibrio.</strong>
        </p>
      </Reveal>
    </Section>
  )
}
