'use client'

import { Gift, ListChecks, ShieldAlert, Dumbbell } from 'lucide-react'
import { Reveal } from './reveal'
import { Section, Kicker, Heading } from './shared'

const BONUSES = [
  {
    icon: Dumbbell,
    n: 'Bono #1',
    title: 'Aplicación digital de tu dieta japonesa personalizada',
    desc: 'Una herramienta práctica para organizar tus elecciones alimentarias y visualizar tu rutina durante el protocolo.',
    value: '$27',
  },
  {
    icon: ListChecks,
    n: 'Bono #2',
    title: 'Planner de Hábitos Diarios Cruciales',
    desc: 'Una herramienta sencilla para registrar y mantener los hábitos importantes de tu rutina para diabetes y neuropatía.',
    value: '$19',
  },
  {
    icon: ShieldAlert,
    n: 'Bono #3',
    title: 'Checklist Diario de los Pies',
    desc: 'Una lista sencilla para incorporar la observación visual de tus pies a tu rutina diaria y evitar que este cuidado quede olvidado.',
    value: '$17',
  },
]

export function Block06Bonus() {
  return (
    <Section tone="muted">
      <Reveal className="text-center">
        <Kicker>
          <Gift className="size-4" />
          Bonos exclusivos
        </Kicker>
        <Heading className="mt-6">Además, recibirás estos bonos</Heading>
      </Reveal>

      <div className="mt-8 space-y-3">
        {BONUSES.map((b, i) => (
          <Reveal key={b.title} delay={80 + i * 90}>
            <div className="rounded-2xl border border-border bg-card p-4 sm:p-5">
              <div className="flex items-start gap-3">
                <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <b.icon className="size-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-display text-[10px] font-bold uppercase tracking-[0.16em] text-primary">
                        {b.n}
                      </p>
                      <h3 className="mt-0.5 font-display text-[15px] font-extrabold leading-tight tracking-tight text-foreground">
                        {b.title}
                      </h3>
                    </div>
                    <span className="shrink-0 rounded-full bg-secondary px-2.5 py-1 font-display text-xs font-bold text-muted-foreground line-through">
                      {b.value}
                    </span>
                  </div>
                  <p className="mt-2 max-w-prose text-pretty text-xs leading-5 text-muted-foreground">
                    {b.desc}
                  </p>
                </div>
              </div>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal delay={120} className="mt-8">
        <div className="flex flex-col items-center gap-1 rounded-2xl border-2 border-dashed border-primary/40 bg-primary/5 py-6 text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
            Valor total
          </span>
          <span className="font-display text-4xl font-extrabold text-foreground line-through decoration-primary/60 decoration-2">
            $63
          </span>
          <span className="mt-1 text-sm font-bold uppercase tracking-wide text-primary">
            Pero hoy no pagarás $63
          </span>
        </div>
      </Reveal>
    </Section>
  )
}
