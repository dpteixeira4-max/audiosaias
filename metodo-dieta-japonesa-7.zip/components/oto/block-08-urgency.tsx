'use client'

import { Clock, AlertTriangle } from 'lucide-react'
import { Reveal } from './reveal'
import { Section, Heading } from './shared'
import { Countdown } from './countdown'

export function Block08Urgency() {
  return (
    <Section tone="dark">
      <Reveal className="text-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-warning/40 bg-warning/15 px-4 py-1.5 font-display text-xs font-bold uppercase tracking-[0.18em] text-warning">
          <Clock className="size-4" />
          Solo por esta página
        </span>
        <Heading className="mt-6 text-background">
          Esta oferta desaparece cuando salgas de aquí
        </Heading>
        <p className="mx-auto mt-4 max-w-lg text-pretty text-base leading-relaxed text-background/70">
          El Método de la Dieta Japonesa de 14 Días a este precio solo está disponible <strong className="text-background">ahora mismo</strong>,
          como complemento a tu compra. No aparecerá de nuevo ni en tu área de miembros.
        </p>
      </Reveal>

      <Reveal delay={120} className="mt-10">
        <Countdown />
      </Reveal>

      <Reveal delay={160} className="mt-8">
        <div className="flex items-start gap-3 rounded-2xl border border-background/15 bg-background/5 p-5">
          <AlertTriangle className="mt-0.5 size-5 shrink-0 text-warning" />
          <p className="text-pretty text-sm leading-relaxed text-background/75">
            Cuando el tiempo llegue a cero, esta página se considerará expirada y el acceso al
            El método volverá a su precio normal.
          </p>
        </div>
      </Reveal>
    </Section>
  )
}
