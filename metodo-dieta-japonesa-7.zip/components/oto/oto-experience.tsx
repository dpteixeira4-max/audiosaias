'use client'

import { useEffect, useState } from 'react'
import { ProcessingLoader } from './processing-loader'
import { Block00SalesHero } from './block-00-sales-hero'
import { JapaneseMethodCopy } from './japanese-method-copy'
import { cn } from '@/lib/utils'

const PASO2_STEPS = [
  'Analizando tu perfil de equilibrio',
  'Seleccionando tu oferta personalizada',
  'Reservando tu acceso exclusivo',
]

export function OtoExperience() {
  // Paso 1 → Paso 2 → contenido
  const [ready, setReady] = useState(false)
  const [ready2, setReady2] = useState(false)

  const revealed = ready && ready2

  useEffect(() => {
    if (revealed) {
      window.scrollTo({ top: 0, behavior: 'auto' })
    }
  }, [revealed])

  return (
    <>
      {!ready && <ProcessingLoader onDone={() => setReady(true)} />}
      {ready && !ready2 && (
        <ProcessingLoader
          onDone={() => setReady2(true)}
          badge="Paso 2 de 3"
          title="Preparando tu oferta"
          subtitle="⚠️ No cierres esta página mientras personalizamos tu oferta."
          steps={PASO2_STEPS}
          duration={17000}
        />
      )}
      <main
        className={cn(
          'transition-opacity duration-700',
          revealed ? 'opacity-100' : 'pointer-events-none opacity-0',
        )}
        aria-hidden={!revealed}
      >
        {/* Página final começa diretamente no mockup da oferta */}
        <div id="pagina">
          <Block00SalesHero />
          <JapaneseMethodCopy />
        </div>

        <footer className="bg-foreground px-4 py-6 text-center text-background/50">
          <p className="text-xs">
            © {new Date().getFullYear()} Método de la Dieta Japonesa · Todos los derechos reservados
          </p>
        </footer>
      </main>
    </>
  )
}
