'use client'

import { Flame } from 'lucide-react'
import { Reveal } from './reveal'
import { CtaButton } from './cta-button'

export function Block00SalesHero() {
  return (
    <section className="bg-background px-4 pb-9 pt-0 text-foreground sm:pb-12">
      <div className="mx-auto w-full max-w-2xl overflow-hidden rounded-b-[2rem] border border-primary/15 bg-card shadow-[0_24px_70px_-35px_color-mix(in_oklch,var(--primary)_45%,transparent)]">
        <div className="bg-destructive px-3 py-2 text-center sm:px-6 sm:py-3">
          <p className="font-display text-[11px] font-extrabold uppercase tracking-[0.12em] text-primary-foreground sm:text-sm">
            Si cierras esta página ahora, perderás el acceso a:
          </p>
        </div>

        <div className="flex flex-col items-center gap-4 px-4 py-5 sm:gap-6 sm:px-10 sm:py-8">
          <div className="max-w-[19rem] text-center sm:max-w-xl">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 font-display text-[9px] font-extrabold uppercase tracking-[0.14em] text-primary sm:text-xs">
              <Flame className="size-3" /> Método de la Dieta Japonesa
            </span>
            <h1 className="mx-auto mt-4 max-w-[18rem] text-pretty font-display text-[1.5rem] font-extrabold uppercase leading-[1.08] tracking-[-0.025em] sm:mt-3 sm:max-w-xl sm:text-balance sm:text-3xl sm:tracking-tight">
              Método de la Dieta Japonesa Personalizada para Impedir la Amputación de tus Pies por Neuropatía
            </h1>
            <p className="mx-auto mt-4 max-w-[19rem] text-pretty text-[0.82rem] leading-6 text-muted-foreground sm:mt-3 sm:max-w-md sm:text-base">
              Un plan digital personalizado según tus datos, diseñado para personas con neuropatía que buscan controlar la glucosa y cuidar tus pies mediante una alimentación adecuada.
            </p>
          </div>

          <div className="relative flex w-full items-center justify-center">
            <div aria-hidden className="absolute inset-0 bg-primary/10 blur-3xl" />
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/banner%20up2-ss8beP1SthAyOK6hJbfNrz1IRk3g2x.png"
              alt="Mockup del Método de la Dieta Japonesa en libro y tablet"
              className="relative w-full max-w-[220px] drop-shadow-2xl sm:max-w-md"
            />
          </div>

          <p className="text-center text-xs font-semibold leading-relaxed text-primary sm:text-sm">
            Esta oferta especial no volverá a aparecer después de salir de esta página.
          </p>
          <CtaButton scrollTo="oferta" subtle className="w-full max-w-[18rem] px-4 py-3 text-center text-xs leading-[1.1] sm:max-w-md sm:px-6 sm:py-5 sm:text-lg"><span>SÍ, QUIERO AÑADIR EL<br />MÉTODO DE LA DIETA JAPONESA</span></CtaButton>
        </div>
      </div>
    </section>
  )
}
