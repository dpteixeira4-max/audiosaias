'use client'

import { CheckCircle2, Flame, Sparkles } from 'lucide-react'
import { Reveal } from './reveal'
import { Section, Kicker, Heading } from './shared'

export function Block02Confirmation() {
  return (
    <Section tone="muted">
      <Reveal className="text-center">
        <Kicker>
          <Sparkles className="size-4" />
          ¡Felicidades!
        </Kicker>
        <Heading className="mt-6">
          Acabas de garantizar tu acceso a
        </Heading>

        <div className="mx-auto mt-6 inline-flex items-center gap-3 rounded-2xl border border-primary/25 bg-card px-6 py-4 shadow-sm">
          <Flame className="size-8 text-primary" />
          <span className="font-display text-xl font-extrabold uppercase tracking-tight sm:text-2xl">
            El Truco de la Pimienta
          </span>
        </div>
      </Reveal>

      <Reveal delay={120} className="mt-8">
        <p className="text-pretty text-center text-base leading-relaxed text-muted-foreground">
          Con él aprenderás un método destinado a trabajar sobre las molestias que pueden
          afectar la sensibilidad de tus pies.
        </p>
      </Reveal>

      <Reveal delay={160} className="mt-10">
        <div className="rounded-3xl border border-success/30 bg-success/10 p-6 text-center sm:p-8">
          <CheckCircle2 className="mx-auto size-9 text-success" />
          <p className="mt-3 font-display text-lg font-extrabold uppercase tracking-tight text-foreground">
            Eso ya es un paso importante.
          </p>
          <p className="mt-4 text-pretty text-base leading-relaxed text-muted-foreground">
            Pero… <strong className="text-foreground">hay algo más que necesitas entender.</strong>{' '}
            Aunque consigas aliviar parte de las molestias, la sensibilidad alterada puede
            continuar afectando la forma en que percibes el suelo y controlas tus
            movimientos.
          </p>
          <p className="mt-4 text-pretty text-base font-semibold leading-relaxed text-foreground">
            Y ahí aparece una segunda pieza fundamental: tu equilibrio al caminar.
          </p>
        </div>
      </Reveal>
    </Section>
  )
}
