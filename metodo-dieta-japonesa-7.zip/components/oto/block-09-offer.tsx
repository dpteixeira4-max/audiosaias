'use client'

import { Check, Lock, CreditCard, ShieldCheck } from 'lucide-react'
import { Reveal } from './reveal'
import { Section, Kicker, Heading } from './shared'
import { CtaButton } from './cta-button'

const INCLUDES = [
  'Método completo de 14 días paso a paso',
  'Sistema progresivo de 3 fases (Activar · Estabilizar · Proteger)',
  'Bono #1 · Aplicación digital de dieta japonesa',
  'Bono #2 · Checklist Diario del Progreso',
  'Bono #3 · Guía de Seguridad y Precauciones',
  'Acceso inmediato y de por vida',
]

export function Block09Offer() {
  return (
    <Section id="oferta">
      <Reveal className="text-center">
        <Kicker>Tu oferta de hoy</Kicker>
        <Heading className="mt-4 text-balance text-[1.4rem] leading-[1.1] sm:mt-6 sm:text-3xl">Añade el Método de la Dieta Japonesa a tu pedido ahora</Heading>
      </Reveal>

      <Reveal delay={100} className="mt-8">
        <div className="overflow-hidden rounded-3xl border-2 border-primary/40 bg-card shadow-xl shadow-primary/5">
          <div className="bg-primary px-6 py-4 text-center">
            <p className="font-display text-sm font-bold uppercase tracking-[0.18em] text-primary-foreground">
              Oferta exclusiva de esta página
            </p>
          </div>

          <div className="p-4 sm:p-8">
            <ul className="space-y-3">
              {INCLUDES.map((item) => (
                <li key={item} className="flex items-start gap-3 text-sm text-foreground">
                  <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-success/15 text-success">
                    <Check className="size-3.5" />
                  </span>
                  {item}
                </li>
              ))}
            </ul>

            <div className="mt-8 flex flex-col items-center">
              <p className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
                Precio normal <span className="line-through decoration-destructive/70">US$97</span>
              </p>
              <div className="mt-1 flex items-end gap-2">
                <span className="font-display text-6xl font-extrabold leading-none text-primary">
                  US$37
                </span>
                <span className="mb-1 font-display text-lg font-bold text-muted-foreground">
                  pago único
                </span>
              </div>
              <p className="mt-2 rounded-full bg-success/15 px-4 py-1 text-xs font-bold uppercase tracking-wide text-success">
                Ahorras más del 70% solo hoy
              </p>
            </div>

            <div className="mt-8">
              <CtaButton size="default" className="px-4 py-3 text-[12px] leading-[1.1] sm:px-6 sm:py-5 sm:text-lg"><span className="max-w-[15rem] text-center">SÍ, QUIERO AÑADIR EL<br />MÉTODO DE LA DIETA JAPONESA</span></CtaButton>
            </div>

            <p className="mt-4 text-center text-xs text-muted-foreground">
              Se añadirá a tu compra actual con un solo clic.
            </p>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <Lock className="size-4 text-success" /> Pago seguro
              </span>
              <span className="flex items-center gap-1.5">
                <CreditCard className="size-4 text-success" /> Sin cargos ocultos
              </span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="size-4 text-success" /> Acceso inmediato
              </span>
            </div>
          </div>
        </div>
      </Reveal>
    </Section>
  )
}
