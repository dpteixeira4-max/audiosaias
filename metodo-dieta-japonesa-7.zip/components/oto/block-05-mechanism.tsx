'use client'

import { Footprints, Eye, Brain, Sun, Flame, Moon, ChevronDown, Info } from 'lucide-react'
import { Reveal } from './reveal'
import { Section, Kicker, Heading } from './shared'

const SYSTEMS = [
  { icon: Footprints, title: 'Los pies y el cuerpo', tag: 'Propiocepción' },
  { icon: Eye, title: 'La visión', tag: 'Referencia visual' },
  { icon: Brain, title: 'El sistema vestibular', tag: 'Equilibrio interno' },
]

const PHASES = [
  {
    icon: Sun,
    n: 'Fase 1',
    title: 'Activar',
    quote: 'Despierta tu control corporal.',
    desc: 'Prácticas suaves para trabajar la conciencia de la posición corporal y la distribución del peso.',
  },
  {
    icon: Flame,
    n: 'Fase 2',
    title: 'Estabilizar',
    quote: 'Controla antes de avanzar.',
    desc: 'Organización práctica para aplicar hábitos de alimentación consciente y autocuidado.',
  },
  {
    icon: Moon,
    n: 'Fase 3',
    title: 'Proteger',
    quote: 'Haz que cada paso sea más seguro.',
    desc: 'Estrategias para reconocer riesgos, mejorar la seguridad del entorno y reducir situaciones que pueden favorecer tropiezos.',
  },
]

export function Block05Mechanism() {
  return (
    <Section>
      <Reveal className="text-center">
        <Kicker>Mecanismo único</Kicker>
        <Heading className="mt-6">Tu bienestar empieza con 3 hábitos diarios</Heading>
        <p className="mx-auto mt-5 max-w-xl text-pretty text-base leading-relaxed text-muted-foreground">
          Cuando caminas, tu cerebro no depende únicamente de tus ojos. Utiliza información
          procedente de:
        </p>
      </Reveal>

      <div className="mt-8 grid gap-3 sm:grid-cols-3">
        {SYSTEMS.map((s, i) => (
          <Reveal key={s.title} delay={80 + i * 90}>
            <div className="flex h-full flex-col items-center rounded-2xl border border-border bg-card px-4 py-6 text-center">
              <span className="flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                <s.icon className="size-6" />
              </span>
              <p className="mt-3 font-display text-sm font-bold uppercase tracking-tight">{s.title}</p>
              <p className="mt-1 text-xs text-muted-foreground">{s.tag}</p>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal delay={120} className="mt-6">
        <p className="text-pretty text-center text-sm leading-relaxed text-muted-foreground">
          Estos sistemas trabajan juntos para ayudarte a mantener la postura y controlar tus
          movimientos. Cuando la sensibilidad de los pies está alterada, esa información puede
          disminuir. Por eso el método utiliza una estructura sencilla de hábitos, observación y rutina:
        </p>
      </Reveal>

      {/* phases */}
      <div className="mt-8 space-y-3">
        {PHASES.map((p, i) => (
          <Reveal key={p.title} delay={80 + i * 100}>
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="flex items-start gap-4">
                <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                  <p.icon className="size-6" />
                </span>
                <div className="min-w-0">
                  <p className="font-display text-xs font-bold uppercase tracking-widest text-primary">
                    {p.n}
                  </p>
                  <h3 className="font-display text-xl font-extrabold uppercase tracking-tight">
                    {p.title}
                  </h3>
                  <p className="mt-1 text-sm italic text-muted-foreground">“{p.quote}”</p>
                  <p className="mt-2 text-pretty text-sm leading-relaxed text-muted-foreground">
                    {p.desc}
                  </p>
                </div>
              </div>
            </div>
            {i < PHASES.length - 1 && (
              <div className="flex justify-center py-1 text-primary">
                <ChevronDown className="size-5" />
              </div>
            )}
          </Reveal>
        ))}
      </div>

      <Reveal delay={120} className="mt-10">
        <div className="rounded-3xl border border-primary/25 bg-primary/5 p-6 sm:p-8">
          <div className="flex items-center gap-2 text-primary">
            <Info className="size-5" />
            <h3 className="font-display text-lg font-extrabold uppercase tracking-tight">
              ¿Qué es exactamente el método?
            </h3>
          </div>
          <ul className="mt-4 space-y-1.5 text-sm text-muted-foreground">
            <li>No es una dieta extrema.</li>
            <li>No es otro medicamento.</li>
            <li>No promete curar la neuropatía.</li>
          </ul>
          <p className="mt-4 text-pretty text-base font-medium leading-relaxed text-foreground">
            Es un programa educativo de 14 días que combina alimentación consciente, planificación sencilla y cuidados diarios para ayudarte a proteger tus pies y acompañar tu bienestar.
          </p>
        </div>
      </Reveal>
    </Section>
  )
}
