'use client'

import { X, Check, Flame, Plus } from 'lucide-react'
import { Reveal } from './reveal'
import { Section, Kicker, Heading, Divider } from './shared'

export function Block03Dichotomy() {
  return (
    <Section>
      <Reveal className="text-center">
        <Kicker>El problema real</Kicker>
        <Heading className="mt-6">Existe una enorme diferencia entre…</Heading>
      </Reveal>

      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        <Reveal delay={80}>
          <div className="flex h-full flex-col rounded-3xl border border-destructive/25 bg-destructive/5 p-6">
            <div className="flex items-center gap-2">
              <span className="flex size-9 items-center justify-center rounded-full bg-destructive/15 text-destructive">
                <X className="size-5" />
              </span>
              <span className="font-display text-sm font-bold uppercase tracking-wide text-destructive">
                Solo el básico
              </span>
            </div>
            <p className="mt-4 text-pretty text-sm leading-relaxed text-muted-foreground">
              Seguir únicamente una lista aislada de consejos sin
              un método completo para organizar tus comidas y cuidados{' '}
              <strong className="text-foreground">sin</strong> trabajar específicamente tu
              alimentación, observación y cuidado diario de los pies.
            </p>
          </div>
        </Reveal>

        <Reveal delay={160}>
          <div className="relative flex h-full flex-col rounded-3xl border-2 border-success/40 bg-success/10 p-6">
            <span className="absolute -top-3 right-5 rounded-full bg-success px-3 py-1 font-display text-[0.65rem] font-bold uppercase tracking-wide text-success-foreground">
              Recomendado
            </span>
            <div className="flex items-center gap-2">
              <span className="flex size-9 items-center justify-center rounded-full bg-success/20 text-success">
                <Check className="size-5" />
              </span>
              <span className="font-display text-sm font-bold uppercase tracking-wide text-success">
                El método completo
              </span>
            </div>
            <p className="mt-4 text-pretty text-sm leading-relaxed text-muted-foreground">
              Método de la Dieta Japonesa de 14 Días
            </p>
            <div className="my-2 flex items-center gap-2 text-muted-foreground">
              <Plus className="size-4" />
            </div>
            <div className="flex items-start gap-2">
              <Flame className="mt-0.5 size-5 shrink-0 text-primary" />
              <p className="text-pretty text-sm font-semibold leading-relaxed text-foreground">
                Guía de 14 días para crear hábitos de alimentación consciente y cuidados diarios.
              </p>
            </div>
          </div>
        </Reveal>
      </div>

      <Divider />

      <Reveal delay={80} className="space-y-4 text-pretty text-base leading-relaxed text-muted-foreground">
        <p>
          Tus pies cumplen una función mucho más importante que simplemente sentir dolor. La
          información procedente de los pies forma parte de la{' '}
          <strong className="text-foreground">propiocepción</strong> y del control postural,
          junto con la información visual y del sistema vestibular.
        </p>
        <p>
          Cuando la sensibilidad periférica está reducida, el cerebro puede recibir menos
          información sobre el contacto del pie con el suelo. Y entonces algo tan simple como:
        </p>
      </Reveal>

      <Reveal delay={140} className="mt-6">
        <div className="flex flex-wrap items-center justify-center gap-2 text-center font-display text-sm font-bold uppercase tracking-tight sm:text-base">
          {['Levantarte', 'Girar', 'Caminar'].map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <span className="rounded-full border border-border bg-card px-4 py-2 text-foreground">
                {s}
              </span>
              {i < 2 && <span className="text-primary">→</span>}
            </div>
          ))}
        </div>
        <p className="mt-4 text-center text-sm font-semibold text-foreground">
          …puede exigir mucho más control.
        </p>
      </Reveal>

      <Reveal delay={120} className="mt-8">
        <div className="rounded-2xl border border-primary/25 bg-primary/5 p-6 text-center">
          <p className="text-pretty leading-relaxed text-muted-foreground">
            Un tropiezo. Un paso inseguro. Una pérdida de equilibrio. Una caída.
            <br />
            <span className="mt-2 inline-block font-display font-bold uppercase tracking-tight text-foreground">
              Por eso creamos el Método de la Dieta Japonesa de 14 Días.
            </span>
          </p>
        </div>
      </Reveal>
    </Section>
  )
}
