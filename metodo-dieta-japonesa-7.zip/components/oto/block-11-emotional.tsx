'use client'

import { Heart } from 'lucide-react'
import { Reveal } from './reveal'
import { Section } from './shared'

export function Block11Emotional() {
  return (
    <Section tone="dark">
      <Reveal className="text-center">
        <span className="flex justify-center">
          <Heart className="size-8 text-primary" />
        </span>
        <p className="mt-4 font-display text-xs font-bold uppercase tracking-[0.2em] text-background/60">
          Imagina cómo sería
        </p>
      </Reveal>

      <Reveal delay={120} className="mt-6 space-y-5 text-pretty text-center text-lg leading-relaxed text-background/85">
        <p>
          Imagina volver a caminar por tu casa <strong className="text-background">sin ir agarrándote a las paredes</strong>.
        </p>
        <p>
          Imagina levantarte de la silla y dar un paso con la tranquilidad de que tu cuerpo
          responde.
        </p>
        <p>
          Imagina salir a la calle, girar, subir un escalón… y sentir de nuevo{' '}
          <strong className="text-primary">que tienes el control</strong>.
        </p>
      </Reveal>

      <Reveal delay={160} className="mt-10">
        <div className="mx-auto max-w-lg rounded-3xl border border-background/15 bg-background/5 p-6 text-center">
          <p className="text-pretty text-base leading-relaxed text-background/75">
            No se trata solo de sentir menos molestias. Se trata de recuperar tu{' '}
            <strong className="text-background">independencia</strong>, tu{' '}
            <strong className="text-background">confianza</strong> y tu{' '}
            <strong className="text-background">libertad de movimiento</strong>.
          </p>
        </div>
      </Reveal>
    </Section>
  )
}
